package testcases_sep29;

import org.testng.annotations.Test;

import base.TestBase;

public class CreateAccount extends TestBase {

	@Test
	public void CreateAccountTest001() {
		homePageObj.getSignInLink().click();
		authPageObj.setEmailaddressCreateAccount("santosh11@test.com");
		authPageObj.getCraeteanaccountbutton().click();
		
		createAccountObj.setFirstName("Santosh");
		createAccountObj.setLastName("Kumar");
		createAccountObj.getGenderselectMale().click();
		
		
		
	}
	
	
}
