package testcases_sep29;

import static org.testng.Assert.assertEquals;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.TestBase;

public class LoginTestcases extends TestBase {

	@Test
	public void loginTest001() {
		homePageObj.getSignInLink().click();
		authPageObj.setEmailaddressSignIn("santosh@test.com");
		authPageObj.setPassword("123456");
		authPageObj.getSigninbutton().click();
		
		Assert.assertEquals(myAccountObj.getSignout().isDisplayed(), true);
		System.out.println("LoginTest001 is PASS");
	}
	
	@Test
	public void loginTest002() {
		homePageObj.getSignInLink().click();
		authPageObj.setEmailaddressSignIn("santosh@test.com");
		authPageObj.setPassword("123456");
		authPageObj.getSigninbutton().click();
	}

	
}
